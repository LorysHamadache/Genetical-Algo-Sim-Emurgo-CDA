

module Main where

import Graphics.Gloss

main :: IO ()
main = display window background drawing
    where
      window = InWindow "Lorys - Haskell Project " (800, 800) (0, 0) 
      background = red 
      drawing = Circle 80